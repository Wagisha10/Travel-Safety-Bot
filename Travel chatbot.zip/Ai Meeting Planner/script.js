let GEMINI_API_KEY = 'AIzaSyDp1uF7lf8D0N1wxr5nV43lW1GCQqHAVlw'; // Replace with a valid key if available
let travelChecks = [];

document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    setupChatbot();
    loadTravelChecks();
});

function setupEventListeners() {
    const safetyForm = document.getElementById('safety-form');
    const contactForm = document.getElementById('contact-form');
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.nav');

    safetyForm.addEventListener('submit', (e) => {
        e.preventDefault();
        checkSafety();
    });

    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        sendContactMessage();
    });

    navToggle.addEventListener('click', () => {
        nav.classList.toggle('active');
    });

    document.querySelectorAll('.nav a').forEach(link => {
        link.addEventListener('click', () => {
            nav.classList.remove('active');
        });
    });
}

function setupChatbot() {
    const chatbotButton = document.getElementById('chatbot-button');
    const chatbotWindow = document.getElementById('chatbot-window');
    const chatbotInput = document.getElementById('chatbot-input');
    const closeButton = document.getElementById('close-chatbot');

    chatbotButton.addEventListener('click', () => {
        chatbotWindow.style.display = chatbotWindow.style.display === 'none' ? 'flex' : 'none';
        if (chatbotWindow.style.display === 'flex') chatbotInput.focus();
    });

    closeButton.addEventListener('click', () => {
        chatbotWindow.style.display = 'none';
    });

    addMessageToChat('bot', 'Hello! I’m TravelBot, here to help you travel safely. Ask about destinations, safety tips, or emergencies!');
    chatbotInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
}

function sendMessage() {
    const input = document.getElementById('chatbot-input');
    const message = input.value.trim().toLowerCase();
    if (!message) return;

    addMessageToChat('user', message);
    input.value = '';

    const typingIndicator = addMessageToChat('bot', 'Thinking...', true);

    if (GEMINI_API_KEY && GEMINI_API_KEY !== 'YOUR_GEMINI_API_KEY') {
        getGeminiResponse(message)
            .then(response => {
                typingIndicator.remove();
                addMessageToChat('bot', response);
            })
            .catch(() => {
                typingIndicator.remove();
                addMessageToChat('bot', getMockResponse(message));
            });
    } else {
        setTimeout(() => {
            typingIndicator.remove();
            addMessageToChat('bot', getMockResponse(message));
        }, 1000);
    }
}

function addMessageToChat(sender, message, isTyping = false) {
    const chatbotMessages = document.getElementById('chatbot-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}${isTyping ? ' typing' : ''}`;
    messageDiv.textContent = message;
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    return messageDiv;
}

async function getGeminiResponse(message) {
    const prompt = `You are TravelBot, a friendly and knowledgeable travel safety assistant. Respond clearly and helpfully in a conversational tone. 
    Current travel checks: ${JSON.stringify(travelChecks, null, 2)}. 
    User message: "${message}". 
    - If asked about a destination's safety (e.g., "Is Paris safe?"), provide a safety report in this format:
      Travel Safety Report:
      Destination: [Destination]
      Safety Status: [Status]
      Tips: [Tips]
      Emergency Contact: [Number]
    - If asked to check safety (e.g., "Check safety for Tokyo"), say: "Please use the Safety Check section above!"
    - If asked for safety tips (e.g., "What are some travel safety tips?"), list general safety advice.
    - If asked about emergencies (e.g., "What do I do in an emergency?"), provide emergency guidance.
    - For greetings (e.g., "Hi"), respond warmly (e.g., "Hi there, traveler! How can I assist?").
    - For unrecognized inputs, say: "I’m here to help with travel safety. Could you clarify your question?"`;

    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + GEMINI_API_KEY, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }]
        })
    });

    if (!response.ok) throw new Error('Error fetching response');
    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
}

function getMockResponse(message) {
    // Extract potential destination from the message
    const words = message.split(' ');
    const destination = words.find(word => /^[A-Z]/.test(word)) || words[words.length - 1].replace('?', '').trim();

    if (message.includes('is') && message.includes('safe')) {
        return `Travel Safety Report:
Destination: ${destination || 'Unknown'}
Safety Status: Generally safe (mock data)
Tips: Stay aware of your surroundings, avoid isolated areas at night
Emergency Contact: 112 (example)`;
    } else if (message.includes('check safety') || message.includes('travel to')) {
        setTimeout(() => window.location.hash = '#safety', 1000);
        return "Please use the Safety Check section above!";
    } else if (message.includes('safety tips') || message.includes('how to stay safe')) {
        return `Here are some travel safety tips:
- Keep your belongings secure and avoid flashy displays of wealth.
- Research local customs and laws before you go.
- Share your itinerary with someone you trust.
- Always have a charged phone and emergency numbers handy.`;
    } else if (message.includes('emergency') || message.includes('help')) {
        return `In an emergency:
- Stay calm and assess the situation.
- Call local emergency services (e.g., 911 in the US, 112 in Europe).
- Contact your embassy or consulate if needed.
- Move to a safe location if possible.`;
    } else if (message.includes('hi') || message.includes('hello')) {
        return "Hi there, traveler! How can I assist you today?";
    } else if (message.includes('bye') || message.includes('goodbye')) {
        return "Safe journeys! I’m here if you need me!";
    } else if (message.includes('weather')) {
        return `I don’t have real-time weather data, but I suggest checking a local forecast for ${destination || 'your destination'}! Weather can impact safety, so stay prepared.`;
    } else if (message.includes('thanks') || message.includes('thank you')) {
        return "You’re welcome! Safe travels!";
    } else {
        return "I’m here to help with travel safety. Could you clarify your question? Try asking about a destination, safety tips, or emergencies!";
    }
}

function checkSafety() {
    const destination = document.getElementById('destination').value;
    const date = document.getElementById('travel-date').value;
    const notes = document.getElementById('travel-notes').value;

    const travelCheck = { destination, date, notes };
    travelChecks.push(travelCheck);
    localStorage.setItem('travelChecks', JSON.stringify(travelChecks));
    generateSafetyReport();
    document.getElementById('safety-form').reset();
    showSuccess('Safety check completed!');
}

function loadTravelChecks() {
    const storedChecks = localStorage.getItem('travelChecks');
    if (storedChecks) {
        travelChecks = JSON.parse(storedChecks);
        generateSafetyReport();
    }
}

function generateSafetyReport() {
    const safetyOutput = document.getElementById('safety-output');
    safetyOutput.innerHTML = travelChecks.length === 0 ? 'No safety checks yet.' : '<h3>Your Safety Reports</h3>' + travelChecks.map((t, i) => `
        <div class="safety-item" data-index="${i}">
            <strong>${t.destination}</strong><br>
            Date: ${formatDate(t.date)}<br>
            Notes: ${t.notes || 'None'}<br>
            Safety Tips: Stay vigilant, check local advisories (mock data).<br>
            <button class="delete-button" onclick="deleteCheck(${i})">Delete</button>
        </div>`).join('');
}

function deleteCheck(index) {
    travelChecks.splice(index, 1);
    localStorage.setItem('travelChecks', JSON.stringify(travelChecks));
    generateSafetyReport();
    showSuccess('Report deleted!');
}

function sendContactMessage() {
    const name = document.getElementById('contact-name').value;
    const email = document.getElementById('contact-email').value;
    const message = document.getElementById('contact-message').value;
    console.log('Contact:', { name, email, message });
    showSuccess('Message sent!');
    document.getElementById('contact-form').reset();
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function showSuccess(message) {
    const div = document.createElement('div');
    div.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #3182ce; color: #fff; padding: 0.75rem 1.5rem; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); z-index: 3000; font-size: 0.95rem;';
    div.textContent = message;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 3000);
}